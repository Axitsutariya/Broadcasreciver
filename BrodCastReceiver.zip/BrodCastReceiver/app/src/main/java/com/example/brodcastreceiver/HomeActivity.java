package com.example.brodcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.brodcastreceiver.databinding.HomeActivityBinding;

public class HomeActivity extends AppCompatActivity {

    HomeActivityBinding homeActivityBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        homeActivityBinding = HomeActivityBinding.inflate(getLayoutInflater());
        setContentView(homeActivityBinding.getRoot());


        registerNetworkBroadcastForNougat();
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("custom-event-name"));

        homeActivityBinding.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isNetworkConnected()) {
                    Toast.makeText(HomeActivity.this, "On", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(HomeActivity.this, "off", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    private void registerNetworkBroadcastForNougat() {
        registerReceiver(new NetCheckReciver(), new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }


    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra("message");

            if (message.equalsIgnoreCase("on")) {
                homeActivityBinding.data.setVisibility(View.VISIBLE);
                homeActivityBinding.nodata.setVisibility(View.GONE);
            } else {
                homeActivityBinding.data.setVisibility(View.GONE);
                homeActivityBinding.nodata.setVisibility(View.VISIBLE);
            }
        }
    };
}
